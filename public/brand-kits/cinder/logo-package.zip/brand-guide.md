# Cinder

A small-batch coffee roaster storefront for discovering seasonal beans, choosing a grind, and planning a visit to the roastery.

Cinder brings the warmth of a neighborhood roastery to a coffee storefront. Brick red, butter yellow, and a generous slab serif give the identity the character of a printed café poster. The page pairs a bold opening with real coffee photography, illustrated bags, tasting notes, and a short story about the ritual of brewing. Visitors can choose whole bean or ground coffee, build a small basket, and browse the roastery details. The ember symbol connects the name to the heat of roasting. The result is a lively shop with enough room to linger over the next cup.

## Typography

Display: Grindela. Body: DM Sans.

## Logo

A small ember above the hearth line represents roasting heat and the quiet warmth of a daily coffee ritual. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A brick and cream café poster with chunky slab typography, butter-yellow seals, warm photography, and simple illustrated coffee packaging.
