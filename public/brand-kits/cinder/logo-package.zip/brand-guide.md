# Cinder

A small-batch coffee storefront for discovering seasonal beans, choosing a grind, and finding a comfortable brewing and delivery rhythm.

Cinder opens as a roastery package poster, with an oversized tactile coffee pouch at the centre and origin and tasting notes in opposing corners. Cream, kraft, and olive packages give three roasts their own material character against a brick field. A compact order strip puts grind, quantity, and price directly beneath the coffee. The original ember symbol and Grindela typography connect the storefront to the warmth of roasting. A batch ledger makes process and altitude easy to compare, followed by a coffee-cherry photograph and a practical brewing sheet. Visitors can build a basket and save a delivery rhythm while keeping the ritual of the everyday cup in view.

## Typography

Display: Grindela. Body: DM Sans.

## Logo

A small ember above the hearth line represents roasting heat and the quiet warmth of a daily coffee ritual. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

An oversized physically photographed coffee pouch on a brick field, opposing-corner product typography and tasting facts, three coherent paper packages, a hard-edged grind/order strip, batch ledger, coffee-cherry study, and a kitchen-counter brewing sheet.
