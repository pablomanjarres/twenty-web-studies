# Archive

A curated fashion destination for expressive silhouettes and pieces worth keeping.

Archive is a fashion destination for people who dress with intention. The collection brings together expressive outerwear, everyday foundations, and considered accessories, selected for their shape, material, and lasting presence. Its visual language is direct: compressed display typography, strong monochrome campaign photography, and a single decisive cherry accent. Editorial compositions introduce the mood of a collection before a clean catalogue makes the pieces easy to explore. The shopping experience stays light and immediate, with category filters, size choices, and a local shopping bag. Archive treats clothes as part of a personal visual vocabulary, giving each silhouette enough room to make its own statement.

## Typography

Display: Sublime. Body: Manrope.

## Logo

Three staggered archival shelves turn storage into a graphic rhythm, with an open middle shelf pointing toward new discoveries. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Oversized condensed Sublime headlines, monochrome street-fashion photography, clean cataloguing details, and a cherry retail accent.
