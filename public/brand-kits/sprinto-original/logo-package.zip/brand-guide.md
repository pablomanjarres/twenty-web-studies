# sprinto

An energetic urban padel club that makes it easy to book a court, find a game, and make movement part of everyday life.

Sprinto brings the energy of the court into a digital club experience. Built for an urban padel community, the identity combines electric violet, sharp chartreuse, and condensed display typography with an expressive ball-in-motion symbol. The website puts play first: an immediate court view, a compact booking interaction, and clear paths into coaching and social matches. Oversized headlines and diagonal graphic details communicate speed, while the layout stays practical enough to organize a real session. Its purpose is to remove the small obstacles between wanting to play and stepping onto the court, making the club feel open, social, and full of momentum.

## Typography

Display: Anton. Body: DM Sans.

## Logo

A ball and three trailing strokes capture the speed, rhythm, and shared energy of a rally. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A violet-and-chartreuse sports identity, condensed oversized type, cropped court photography, and a compact lime booking card.
