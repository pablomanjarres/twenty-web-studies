# Vale

A botanical skincare storefront that helps visitors discover a small, thoughtful daily ritual.

Vale is a botanical skincare concept built around the quiet pleasure of a daily ritual. A delicate serif, mist green surfaces, and soft limestone textures give the storefront a calm editorial pace. The opening campaign introduces sculptural frosted bottles beside broad leaves, followed by illustrated products and clear descriptions. A morning and evening selector lets visitors explore two simple routines, while the ritual builder gathers a personal selection in place. The leaf and water symbol brings the botanical identity into a single mark. Spacious composition and gentle product storytelling make care feel considered, approachable, and easy to return to.

## Typography

Display: The Foriene. Body: Manrope.

## Logo

Two leaves meet above a small stem, joining botanical ingredients and the balance of a daily ritual. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Soft green botanical luxury with a delicate local serif, large product campaign photography, quiet rules, sculptural packaging, and spacious editorial compositions.
