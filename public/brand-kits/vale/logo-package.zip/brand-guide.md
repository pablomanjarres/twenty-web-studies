# Vale

A botanical skincare storefront that helps visitors discover a small, thoughtful daily ritual.

Vale presents a small skincare collection as a botanical specimen index. Pressed oat, rose, and calendula sit beside individual frosted-glass vessels on a mineral-green ruled sheet. Fine annotations connect each plant, ingredient, and material, while modest serif titles keep the formulas close at hand. Visitors can switch formulas, open an ingredient note, choose a volume, and collect a personal ritual. Macro texture photographs show the character of a light serum and a richer cream. A compact morning and evening sequence, packaging study, and practical questions extend the experience. The identity brings botanical observation and a considered daily routine into one quiet, useful storefront.

## Typography

Display: The Foriene. Body: DM Sans.

## Logo

Two leaves meet above a small stem, joining botanical ingredients and the balance of a daily ritual. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A botanical specimen index on mineral-green ruled paper, pressed plant cutouts, individual frosted-glass vessels, fine ingredient annotations, modest The Foriene typography, macro textures, and a compact daily ritual sequence.
