# vestra

An intimate alpine retreat where guests can explore the property, compare rooms and prepare a dated stay outline with clear nightly pricing.

Vestra brings the feeling of arriving in the mountains into a calm hotel experience. A blue-hour lodge photograph opens the page, revealing warm windows, limestone walls and water beneath the peaks. Midnight blue and mist-white type keep the property in focus, while a curved arrival dock opens into filled date, room and guest controls. Guests can compare three stays, see the nightly total and prepare a clear outline. A room overlooking the pool and a sheltered courtyard carry the same architectural story below. Broad serif headings soften the dark surfaces, and the folded-ridge symbol holds the retreat within its mountain setting.

## Typography

Display: The Foriene. Body: Manrope. Wordmark: Manrope.

## Logo

Two folded mountain ridges meet in a sheltered valley, expressing a retreat held by nature. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

An immersive blue-hour alpine property with a broad low serif headline, midnight curved booking dock, filled native date controls and rounded room disclosures; coherent lodge, suite and courtyard photographs carry the stay through dark atmospheric surfaces.
