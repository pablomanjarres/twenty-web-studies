# vestra

An intimate alpine retreat offering restorative stays, seasonal food, and unhurried ways to experience the mountain landscape.

Vestra is an intimate mountain retreat where the landscape sets the pace. The website opens as a quiet alpine panorama, with a small invitation placed near the valley and an arrival folio that stays out of the view until it is needed. Forest green, warm cream and delicate serif typography carry a measured hospitality identity. Guests can explore room details, select dates and prepare a stay outline, then move through a portrait room journal and the slower rituals of a mountain day. The folded-ridge symbol suggests a sheltered valley. Photography, restrained captions and generous space make the retreat feel connected to its setting.

## Typography

Display: The Foriene. Body: DM Sans.

## Logo

Two folded mountain ridges meet in a sheltered valley, expressing a retreat held by nature. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A quiet alpine panorama with low-corner serif copy, restrained edge navigation and a linen arrival folio; portrait suite photographs and uneven forest journals create a slow editorial rhythm.
