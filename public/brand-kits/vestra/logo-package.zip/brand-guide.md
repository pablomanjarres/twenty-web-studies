# vestra

An intimate alpine retreat offering restorative stays, seasonal food, and unhurried ways to experience the mountain landscape.

Vestra is an intimate alpine retreat where the landscape sets the pace. Its identity brings together deep forest green, warm cream, and expressive serif typography, with a mountain-fold symbol that connects the brand to its setting. The website opens onto a panoramic mountain view, then invites guests into the rooms, seasonal kitchen, and slower rituals of a stay. A simple booking panel makes choosing dates and exploring availability feel straightforward. The experience is designed for travelers seeking quiet rather than spectacle, presenting hospitality as a thoughtful connection to place, with generous photography and small details that leave space to breathe.

## Typography

Display: The Foriene. Body: DM Sans.

## Logo

Two folded mountain ridges meet in a sheltered valley, expressing a retreat held by nature. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Immersive mountain photography with quiet forest-green navigation, elegant serif titles, and a cream booking bar set over the horizon.
