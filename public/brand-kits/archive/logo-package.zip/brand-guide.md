# Archive

A curated fashion destination for expressive silhouettes and pieces worth keeping.

Archive presents a small fashion collection through two architectural campaign studies. A full-frame photograph sets the mood, with a compressed vertical identity at the edge and a quiet filmstrip for changing looks. Each look connects directly to the garments worn in the campaign: a sculptural charcoal coat, an ivory jacket, a tailored black trouser, and a cherry silk accent. The catalogue follows with material details, size choices, category filters, and a shopping bag. Unequal close studies of wool and silk extend the collection's point of view. The identity balances direct condensed typography with measured cataloguing details, warm stone surfaces, and a restrained cherry accent.

## Typography

Display: Sublime. Body: DM Sans.

## Logo

Three staggered archival shelves turn storage into a graphic rhythm, with an open middle shelf pointing toward new discoveries. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Full-frame architectural fashion photography, an edge-set condensed identity, a two-look filmstrip, matching garment studies, warm stone cataloguing surfaces, and a quiet cherry accent.
