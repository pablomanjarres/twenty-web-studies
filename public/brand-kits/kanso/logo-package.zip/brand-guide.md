# kanso

A small ceramics atelier making tactile, thoughtfully shaped objects that add quiet beauty to everyday rituals.

Kanso is a ceramics atelier devoted to the objects people reach for every day. Its identity pairs soft blush and deep cocoa with refined serif typography, allowing material texture and simple forms to take the lead. A hand-drawn vessel symbol captures the slight asymmetry of handmade work. The online shop presents a small collection with generous product photography, restrained descriptions, and an intuitive category filter. A local cart interaction makes selecting a piece feel immediate. The website’s purpose is to translate the atelier’s care into a digital setting, celebrating useful beauty through honest materials, thoughtful spacing, and a shopping experience that feels unhurried.

## Typography

Display: Commune. Body: DM Sans.

## Logo

A softly asymmetric vessel describes the meeting of the maker’s hand, useful form, and daily ritual. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Soft blush and cocoa, a large quiet serif headline, oversized ceramic product photography, and an airy catalogue with a maker-led story.
