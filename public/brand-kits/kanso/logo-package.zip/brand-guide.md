# kanso

A small ceramics atelier making tactile, thoughtfully shaped objects that add quiet beauty to everyday rituals.

Kanso is a small ceramics atelier devoted to useful objects and the slight irregularities of handmade work. Its shop opens as a shelf: six individual forms rest on washed blush paper, with their dimensions, glazes, and prices close at hand. A narrow category index and outlined finish swatches make the collection easy to explore. The quiet Commune wordmark occupies a pause beside the objects, while a vessel symbol recalls the maker’s touch. Product details, quantities, and a personal bag support an unhurried selection. A close surface study, batch specifications, and a photograph of clay on the wheel carry the material story through the rest of the page.

## Typography

Display: Commune. Body: DM Sans.

## Logo

A softly asymmetric vessel describes the meeting of the maker’s hand, useful form, and daily ritual. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

An asymmetric ceramic shelf on washed blush paper, individual tactile product cutouts, a narrow category rail, modest Commune typography, precise dimensions, a blue glaze macro, and a wide pottery-process photograph.
