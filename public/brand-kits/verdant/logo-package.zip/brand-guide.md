# Verdant

A renewable systems company website that explains generation, conversion, demand and storage through an interactive energy-flow canvas and field projects.

Verdant makes renewable energy easier to understand through the relationships that make a system useful. A cool white energy canvas connects generation, conversion, site demand and storage through original isometric hardware illustrations. Rounded source controls switch solar, wind and storage scenarios, while clear readout plates show balanced example flows. Selecting a component brings its role into a dark context bar. Graphite text, slate surfaces and solar yellow accents keep the technical information clear. Field photography carries the story into the landscape, and the horizon symbol connects natural potential with ordered infrastructure. A compact site planner provides a practical starting point for a future connection.

## Typography

Display: Sora. Body: Manrope. Wordmark: Manrope.

## Logo

A rising sun sits over three field lines, connecting natural energy to a considered, ordered landscape. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A cool white technical canvas with original isometric hardware drawings, balanced power lines and filled source capsules. Slate readout plates and a graphite context bar explain the selected node. Solar yellow highlights the flow, with monospaced units reserved for measurements and field photography below.
