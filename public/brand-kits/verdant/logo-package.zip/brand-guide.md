# Verdant

A renewable systems company website that explains generation, conversion, demand and storage through an interactive energy-flow canvas and field projects.

Verdant introduces renewable energy through the relationships that make a system useful. An open energy-flow canvas connects generation, conversion, site demand and storage, with clearly labeled units and an explanation of each stage. A compact source legend switches solar, wind and storage scenarios, changing the diagram and its balanced example flows. Mustard markers, olive ink and small operating annotations give the identity a precise, grounded character. Field photography and a ruled project ledger show how the technical idea extends into the landscape. The horizon symbol joins natural potential with ordered infrastructure. A concise site planner closes the experience with a practical starting point for a future connection.

## Typography

Display: Sora. Body: Manrope.

## Logo

A rising sun sits over three field lines, connecting natural energy to a considered, ordered landscape. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A full-view energy-flow canvas with original isometric hardware drawings, balanced power lines, compact horizontal source controls and small operating annotations; selected-node context sits along the bottom. Olive dots, mustard states and monospaced units give way to field photography below.
