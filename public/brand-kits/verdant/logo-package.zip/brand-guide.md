# Verdant

A renewable energy company website that introduces solar, wind, and storage projects through clear photography and simple diagrams.

Verdant presents renewable energy with the confidence of an architectural practice. Golden mustard, olive, and milk-white surfaces frame large field photography, geometric diagrams, and measured typography. The opening connects a better current to a landscape of wind turbines, while three energy approaches provide a clear path into the project collection. Switching between solar, wind, and storage changes the featured project and its technical illustration. A short energy-flow sequence explains the relationship between generation and everyday use. The horizon symbol joins a rising sun with an ordered field. A local project brief closes the page with a practical way to explore a future energy plan.

## Typography

Display: Sora. Body: Manrope.

## Logo

A rising sun sits over three field lines, connecting natural energy to a considered, ordered landscape. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

An architectural energy journal with mustard and olive planes, panoramic field photography, exposed grid rules, large geometric type, and original technical diagrams.
