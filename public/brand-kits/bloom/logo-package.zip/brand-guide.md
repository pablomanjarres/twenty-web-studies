# Bloom

A personal learning workspace that makes creative practice feel organized, encouraging, and achievable.

Bloom helps creative learners build a practice they can keep. Courses, daily goals, live sessions, and a personal learning path come together in a friendly workspace that celebrates steady progress. Soft lime, peach, and lavender make the interface feel open and inviting, while clear progress data keeps encouragement grounded in real activity. A simple petal symbol represents growth through repeated small steps. Original course illustrations give each subject its own visual character without adding clutter. Learners can search their courses, choose a calendar day, continue a lesson, and mark their practice complete. The dashboard offers enough structure to make the next step obvious, and enough warmth to make it welcome.

## Typography

Display: Sunny Side. Body: Plus Jakarta Sans.

## Logo

Four unfolding petals express the steady cycle of learning, practice, reflection, and growth. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Sunny Side moments inside a clear Jakarta Sans workspace, lime practice panels, playful original course art, and warm precise progress tracking.
