# Bloom

A personal learning workspace that makes creative practice feel organized, encouraging, and achievable.

Bloom makes creative study feel organized and inviting. Two linked courses bring color, spacing, typography and observation into short lessons with clear prerequisites. Course cards show progress from completed practices, while a weekly timetable gives each lesson a place in the learner’s plan. Selecting a session opens its purpose, duration and exercise; completing a practice updates the course progress, learning activity and next available lesson together. A compact calendar, friendly illustrated invitation and milestone view support the same learning journey. Warm white surfaces, lime and rose accents, precise Jakarta Sans lettering and a slim navigation rail keep the workspace modern, gentle and easy to explore on a phone.

## Typography

Display: Plus Jakarta Sans. Body: Plus Jakarta Sans.

## Logo

Four unfolding petals express the steady cycle of learning, practice, reflection, and growth. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Modern personal learning workspace with a slim icon rail, illustrated rose invitation, genuine course-progress panels, a broad lesson timetable and compact lime learning activity; soft white rounded cards and restrained Jakarta Sans typography.
