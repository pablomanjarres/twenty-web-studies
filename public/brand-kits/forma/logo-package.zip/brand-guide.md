# FORMA

An architecture practice creating quiet, enduring spaces through material honesty and close attention to the way people live.

Forma is an architecture practice built around the relationship between people, material, and place. Its digital identity treats every project as a spatial story, allowing generous photography and carefully placed typography to carry the experience. An ivory and charcoal palette echoes plaster, stone, and shadow, while the geometric symbol recalls an open architectural volume. The website pairs a full-width residential interior with a curated project index, a clear account of the studio’s approach, and direct contact information. Its purpose is to help prospective clients understand the practice through the spaces it creates, with the same clarity and care found in its buildings.

## Typography

Display: Manrope. Body: DM Sans.

## Logo

An open, nested architectural volume represents the dialogue between structure and the lives it holds. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Full-bleed interior photography, an oversized geometric studio wordmark, understated ivory panels, and an asymmetric project index.
