# FORMA

An architecture practice creating quiet, enduring spaces through material honesty and close attention to the way people live.

Forma presents architecture through the spaces themselves. A large framed photograph opens beside a narrow project archive, giving each interior room to speak before the studio describes its approach. Selecting a project changes its image, facts, material palette, and spatial study. The page then follows the scale of a physical dossier: a measured plan, a broad detail photograph, a smaller material crop, and quiet practice notes. Paper, charcoal, hairline rules, and compact technical labels recall an architect’s presentation board. The nested volume symbol expresses the relationship between structure and the lives it holds.

## Typography

Display: Manrope. Body: DM Sans.

## Logo

An open, nested architectural volume represents the dialogue between structure and the lives it holds. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A large framed architectural photograph beside a narrow project index, followed by measured dossier facts, original spatial diagrams, uneven material photographs, and restrained ruled contact details.
