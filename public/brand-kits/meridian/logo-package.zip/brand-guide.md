# Meridian

A freight operations workspace for shipment selection, destination handoff planning, and geographic route monitoring.

Meridian brings the freight desk onto a detailed destination planning map. A compact utility bar and icon rail frame richly layered shipment cards, each with an original vessel, aircraft, or truck illustration. Selecting a movement reveals its destination port schematic, expected arrival, cargo, and operational handoff state. Berth, collection, and transfer points support the next planning decision without implying live vehicle positioning. A secondary world view connects the same shipments over geographic coastlines, while the manifest provides a concise operational ledger. Midnight surfaces, restrained cyan routes, and clear status accents keep the working geography in focus. The crossing-route identity connects each destination to one shared operational view.

## Typography

Display: Space Grotesk. Body: DM Sans.

## Logo

Two crossing routes join around a central node, showing connected destinations and a single operational view. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A midnight operational map with dense original port schematics, compact utility navigation, a narrow card rail, detailed vehicle illustrations, and floating arrival and handoff docks. Unequal information surfaces preserve the map as the dominant working area; cyan selects movement and amber marks review states.
