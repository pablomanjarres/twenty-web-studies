# Meridian

A shipment control tower that connects route monitoring, freight status, and arrival planning in one operational workspace.

Meridian is a logistics control tower designed for the rhythm of a busy freight desk. A midnight navy workspace pairs precise cyan route graphics with compact shipment rows, arrival details, and readable operational metrics. The map and table share a selection, so choosing a shipment brings its journey into focus. Search and transport filters narrow the workspace, while a local scheduling panel adds a new movement to the list. Technical mono labels give coordinates and reference numbers a distinct voice. The crossing route symbol represents connected destinations. Every panel supports a clear task: locate a movement, understand its status, and plan the next arrival.

## Typography

Display: Space Grotesk. Body: DM Sans.

## Logo

Two crossing routes join around a central node, showing connected destinations and a single operational view. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A precise midnight operational workspace with compact tables, vector cartography, cyan routes, measured spacing, and selective Caleb Mono technical labels.
