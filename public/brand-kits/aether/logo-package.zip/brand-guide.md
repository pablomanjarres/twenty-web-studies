# aether

A considered money workspace for independent creatives, bringing invoices, income, and everyday spending into one clear rhythm.

Aether brings the rhythm of independent work into a considered money workspace. A satin graphite payment card and translucent ember ribbon make the relationship between work, income, and possibility tangible. Small invoice controls frame the central object, connecting each selected payment to a readable account balance and allocation. The spacious opening gives way to a full-width ledger, where client names, invoice references, and amounts carry the hierarchy. Warm black, quiet paper, and precise money labels support a clear purpose: helping independent creatives understand their finances and make room for their next ambition.

## Typography

Display: Manrope. Body: DM Sans.

## Logo

Two rising arcs and a central point express independent momentum and a steady foundation for financial freedom. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A central satin-metal payment object and ember acrylic ribbon on warm black, with peripheral copy, connected invoice controls, and a full-width ruled ledger on quiet paper.
