# aether

A considered money workspace for independent creatives, bringing invoices, income, and everyday spending into one clear rhythm.

Aether gives independent creatives a calmer relationship with money. The banking experience brings incoming payments, invoice tracking, and everyday spending into one focused workspace. An ember-orange payment card sits at the heart of the identity, surrounded by warm neutrals, precise typography, and sculptural layers that suggest movement without visual noise. The website makes the product tangible through a live currency selector, clear account features, and a concise view of freelance cash flow. Every detail supports a simple purpose: helping people spend less time organizing their finances and more time doing the work they love.

## Typography

Display: Manrope. Body: DM Sans.

## Logo

Three rising arcs express independent momentum and a steady foundation for financial freedom. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Oversized warm-white typography on a matte black field with an offset stack of dimensional payment cards and restrained ember-orange accents.
