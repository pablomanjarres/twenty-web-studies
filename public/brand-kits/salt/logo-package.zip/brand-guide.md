# Salt

A neighborhood seafood restaurant serving honest coastal food and long, easy evenings.

Salt is a coastal neighborhood kitchen with a generous table and a menu shaped by the season. Its website opens as a printed menu spread, pairing dish names, prices and ingredient notes with an overhead plate of garlic prawns. Tomato-red edge tabs make lunch, dinner and drinks easy to explore, while navy rules and cream paper bring the warmth of a restaurant menu into the page. A scallop-shell symbol connects the identity to the coast. Kitchen photographs continue the story, and a receipt-style table planner keeps the practical details close. The experience puts appetite, good company and clear information at the center.

## Typography

Display: Tahoe. Body: DM Sans.

## Logo

A fan-shaped scallop shell brings the coast to the table, with open ribs suggesting shared plates and good company. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A folded seasonal menu on cream paper, tomato-red edge tabs, price-aligned dish columns, an overhead photographic plate cutout and a receipt-style table planner; compact Tahoe titles rather than a large slogan.
