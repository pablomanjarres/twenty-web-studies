# Salt

A neighborhood seafood restaurant serving honest coastal food and long, easy evenings.

Salt is a coastal neighborhood kitchen with a generous table and a menu shaped by the season. Its website puts a bright white menu against deep sea blue, pairing clear dish names, prices and ingredient notes with overhead food photography. Rounded menu controls make dinner, lunch and drinks easy to explore. A bold Tahoe wordmark and scallop-shell symbol give the identity a lively coastal character, while serif dish-group titles make the menu easy to scan. Kitchen photographs continue the story, and a table planner brings the evening's practical details together. The experience puts appetite, good company and clear information at the center.

## Typography

Display: Tahoe. Body: DM Sans. Wordmark: Tahoe.

## Logo

A fan-shaped scallop shell brings the coast to the table, with open ribs suggesting shared plates and good company. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A bright coastal menu on a deep sea-blue stage: bold Tahoe titles, rounded horizontal menu selectors, clear price-aligned columns and an overhead photographic plate. Tomato red brings warmth to the table-planning section, with navy text and white surfaces keeping the food in focus.
