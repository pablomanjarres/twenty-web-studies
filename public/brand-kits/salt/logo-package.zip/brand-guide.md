# Salt

A neighborhood seafood restaurant serving honest coastal food and long, easy evenings.

Salt is a neighborhood seafood kitchen with a coastal point of view and a generous table. Fresh catches, simple ingredients, and a lively room make it a place for both everyday lunches and dinners that stretch into the evening. The visual identity pairs spirited red typography with navy nautical details and bright food photography. A scallop shell anchors the brand without relying on familiar restaurant lettering or crests. The website puts appetite first, then makes the practical details easy: explore the seasonal menu, learn about the kitchen, and choose a table time. It is warm, direct, and full of seaside character.

## Typography

Display: Tahoe. Body: DM Sans.

## Logo

A fan-shaped scallop shell brings the coast to the table, with open ribs suggesting shared plates and good company. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Spirited Tahoe typography, tomato red, simple scallop and wave drawings, close food photography, and an asymmetric seasonal menu.
