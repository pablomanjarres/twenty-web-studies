# Offgrid

A brand and digital studio for culture, fashion and independent businesses with a strong point of view.

Offgrid gives a creative studio a website with the energy of a pasted-up street poster. Wide retro typography sits against cobalt blue and marigold, with fashion photography, ribbed-glass imagery and offset project frames making the work feel physical. The layout changes scale from a loud first screen to a clear project index, then a simple brief builder. Visitors can filter the work by discipline and assemble a short project note. The symbol is an open grid with one cell moved outside its frame, giving the studio a recognizable mark that expresses an idea leaving the expected structure.

## Typography

Display: Tahoe. Body: DM Sans.

## Logo

An open structural grid with one displaced cell represents an idea finding a different position. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Cobalt and marigold poster experiment with wide retro type, offset photography, physical collage marks and expressive project frames.
