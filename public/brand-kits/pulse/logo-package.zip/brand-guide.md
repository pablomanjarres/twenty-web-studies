# pulse

A humane clinical workspace that brings appointments, patient context, and practice activity into a calm, legible daily view.

Pulse brings the care team, the working week and the next patient into one clear clinical workspace. Its overview combines scheduled care time, accurate appointment totals and a selectable weekly activity chart with a portrait-led appointment ledger. Choosing a day updates every summary and the daily appointment list from the same visits. A separate calendar provides timed clinician lanes and a chronological phone agenda, while searchable patient records preserve context and editable conversation notes. New visits use the available schedule rather than creating conflicting appointments. Dark teal navigation, lemon accents and quiet white cards make the administrative view feel calm, precise and easy to scan.

## Typography

Display: Outfit. Body: DM Sans.

## Logo

A continuous pulse line inside a protective circle represents steady, connected care. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Modern clinical overview with unequal columns of scheduled care statistics, a dominant pill-bar activity chart, temporal appointment cards and a portrait-led ledger; rounded white surfaces, dark teal pill navigation and precise lemon accents.
