# pulse

A humane clinical workspace that brings appointments, patient context, and practice activity into a calm, legible daily view.

Pulse is a clinical workspace designed around the people behind every appointment. Its dashboard brings the day’s schedule, patient context, and practice activity into one calm view, using teal for clarity and warm peach for a more welcoming tone. Rounded charts and readable data support quick decisions without overwhelming the interface. The identity’s interlocking pulse symbol connects continuity of care with steady forward movement. Date selection and appointment filtering make the daily schedule interactive, while realistic patient cards and activity details establish useful context. The design’s purpose is to give care teams a reliable overview of the day, leaving more attention for the conversations that matter.

## Typography

Display: Outfit. Body: DM Sans.

## Logo

A continuous pulse line inside a protective circle represents steady, connected care. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A calm mint clinical workspace with a teal navigation rail, peach appointment highlights, spacious patient rows, and a rounded activity chart.
