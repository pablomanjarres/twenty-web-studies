# Monograph

An independent journal for the people, places, and ideas shaping contemporary art.

Monograph is an independent journal for curious eyes. A narrow gallery-blue index accompanies a living wall of photographs, essays, and studio observations on warm paper. Four unequal columns create a reading rhythm of their own: a long exhibition view, a floating colour study, a sculptural detail, and a small record of work. Delicate serif headlines and precise publishing notes keep the imagery in focus. Readers can change the issue, explore subjects, open a longer essay, and keep a personal reading list. Below the wall, exhibition archives and a printed edition invite a slower encounter with art, objects, and the spaces between them.

## Typography

Display: The Foriene. Body: DM Sans.

## Logo

Two open editorial columns form an abstract journal spread, holding art and criticism in conversation. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A compact navy issue rail, four unequal photographic story columns on off-white paper, The Foriene headlines, quiet credits, long visual essays, and ruled exhibition notes.
