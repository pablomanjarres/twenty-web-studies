# Monograph

An independent journal for the people, places, and ideas shaping contemporary art.

Monograph is an independent art and culture journal for curious readers. Its editorial world brings together exhibition visits, artist conversations, and considered writing on the spaces around us. A generous serif masthead and deep gallery blue establish a confident publishing identity, while warm paper surfaces give photographs room to breathe. The magazine moves between large visual essays and shorter studio notes without flattening them into the same format. Readers can explore stories by subject and save the pieces they want to return to. The experience feels like opening a beautifully printed issue, with the ease of a digital reading room.

## Typography

Display: Commune. Body: DM Sans.

## Logo

Two open editorial columns form an abstract journal spread, holding art and criticism in conversation. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A generous Commune masthead, gallery-scale art photography, deliberate asymmetry, and small publishing details on warm paper.
