# Estelle

A jewelry atelier creating sculptural pieces with an intimate, enduring sense of beauty.

Estelle presents sculptural jewellery as a quiet exhibition of form, material, and touch. Two unequal photographic apertures show each piece close and worn, separated by a slender atelier wordmark on ivory. A folded ring and a pair of elongated petal earrings establish a small, considered collection. Visitors can study gold and silver through matching views, read dimensions and finish notes, and move from the polished object to the workbench behind it. Delicate serif titles and fine annotations keep the attention on the metal. A personal viewing folio gathers the chosen piece, material, and preferred atelier hour into one unhurried encounter.

## Typography

Display: The Foriene. Body: DM Sans.

## Logo

Four curved rays surround a central point of light, recalling the evening star and the quiet radiance of jewelry worn close. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Ivory museum-like exhibition with unequal macro and worn-photo apertures, a slim central The Foriene wordmark, gold and silver surface studies, fine annotations, and a plum appointment folio.
