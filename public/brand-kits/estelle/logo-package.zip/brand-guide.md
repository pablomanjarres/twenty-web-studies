# Estelle

A jewelry atelier creating sculptural pieces with an intimate, enduring sense of beauty.

Estelle is a jewelry atelier devoted to the intimate beauty of objects worn close. Sculptural curves, warm gold, and carefully balanced stones define a collection that feels expressive without excess. The brand’s identity draws on the evening star: a small point of light with a lasting presence. Deep plum surfaces and champagne gold give the website a rich, quiet atmosphere, while graceful serif typography keeps the presentation personal. Close product photography reveals material and form before inviting visitors to explore the collection or choose an atelier appointment. Each composition gives the jewelry time and space, presenting pieces as future keepsakes rather than passing accessories.

## Typography

Display: The Foriene. Body: Manrope.

## Logo

A hand-shaped evening star surrounds a single gem, expressing subtle radiance and jewelry held close. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

The Foriene serif, dark plum marble and champagne gold, generous negative space, intimate sculptural product photography, and fine jewelry detailing.
