# Wayfarer

A travel journal and collection of small-group journeys for people who want to spend more time outside.

Wayfarer is a travel journal built around the feeling of arriving somewhere on foot. Sweeping mountain photography, sky blue surfaces and a deep navy identity give the website the pace of a field notebook. A broad landscape introduces the destination before the trip details appear. The journey index lets readers move between alpine routes and slower countryside escapes, while the editorial section makes room for practical notes from the trail. The custom trail symbol connects a winding path with a rising sun. The result is a place to discover a route, read its story and choose the next journey.

## Typography

Display: Sora. Body: Manrope.

## Logo

Two winding trail lines rise toward a sun, expressing exploration and an open destination. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Landscape-led travel editorial with broad sky blue fields, substantial sans serif headings and small field-note details.
