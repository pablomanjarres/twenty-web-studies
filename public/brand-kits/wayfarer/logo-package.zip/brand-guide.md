# Wayfarer

A guided walking service that helps travelers explore routes, compare trail facts and prepare small-group departures through an interactive field atlas.

Wayfarer is a field guide to small-group walking journeys. Its first page unfolds as a trail atlas, bringing route lines, contour drawings, destination photographs and practical itinerary details into one readable spread. Travelers can choose an alpine or countryside route, compare distance and ascent, and prepare a departure plan without losing the landscape. Blue ink, warm field paper and compact notebook typography connect the identity to time spent outdoors. Uneven editorial photographs and guide notes continue the story beyond the map. The winding trail symbol expresses a journey with room for discovery, while clear route facts help make the next step feel possible.

## Typography

Display: Bricolage Grotesque. Body: Manrope.

## Logo

Two winding trail lines rise toward a sun, expressing exploration and an open destination. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A folded trail atlas in blue ink and warm field paper, with original contour drawings, pinned destination photographs, compact Bricolage titles, monospaced route facts and a narrow itinerary folio.
