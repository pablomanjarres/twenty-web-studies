# Wayfarer

A small-group walking service that helps travelers choose a destination, follow an illustrated route, compare trail facts and prepare a departure plan.

Wayfarer makes choosing a walking journey feel close to the ground. Its first view brings three unequal surfaces together: a tall photograph of walkers, a mineral-blue illustrated atlas and a charcoal trip planner. Destination pills change the photograph, route line, four stops and practical facts in one place. Travelers can compare alpine and countryside journeys, choose a departure and add a local plan without losing their bearings. Filled controls, compact trail quantities and warm yellow actions keep the next step clear. Walking notes continue below in rounded disclosures. The winding-trail symbol expresses a journey that leaves room for discovery, with the landscape always part of the decision.

## Typography

Display: Bricolage Grotesque. Body: Manrope. Wordmark: Manrope.

## Logo

Two winding trail lines rise toward a sun, expressing exploration and an open destination. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A photograph-led journey explorer with three unequal photo, mineral-blue atlas and charcoal itinerary panels; rounded destination pills, filled departure controls, original contour geometry and route-specific walking photographs replace the folded-paper treatment.
