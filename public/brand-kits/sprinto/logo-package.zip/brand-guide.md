# sprinto

An energetic urban padel club that makes it easy to book a court, find a game, and make movement part of everyday life.

Sprinto is an urban padel club built around getting people onto the court. A warm playing environment fills the opening screen, with a compact date, court and time selector anchored directly within it. Electric violet and chartreuse give the club a clear athletic identity without hiding the practical booking details. An exposed availability board makes open sessions easy to scan, while ruled fixture rows introduce weekly social matches and coaching. The ball-in-motion symbol captures the rhythm of a rally. Condensed club typography, direct pricing and large selected states bring the energy of padel into an approachable experience for new players and regulars alike.

## Typography

Display: Anton. Body: DM Sans.

## Logo

A ball and three trailing strokes capture the speed, rhythm, and shared energy of a rally. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A photographic padel environment with an integrated cream booking stack, hard-edged chartreuse confirmation, compact Anton club identity, exposed court timetables and ruled social-match fixtures.
