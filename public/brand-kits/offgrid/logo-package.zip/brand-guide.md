# Offgrid

A brand and digital studio for culture, fashion and independent businesses with a strong point of view.

Offgrid is an independent design studio with a clear appetite for the unexpected. Its first screen is a cobalt typographic poster: a small manifesto, a ruled vertical project menu, and a large cropped Tahoe wordmark carry the identity without a promotional image. Selected work opens into three different art-directed worlds, combining original typographic compositions, photographic material, printed pieces, and purposeful changes in scale. Warm milk and marigold give the supporting pages a direct, tactile character. Visitors can switch projects to see their visual language, scope, and story, read the studio’s working principles, and build a downloadable project brief as a starting point for a future conversation.

## Typography

Display: Tahoe. Body: DM Sans.

## Logo

An open structural grid with one displaced cell represents an idea finding a different position. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A full-field cobalt poster with a dramatically cropped Tahoe wordmark, an upper-corner manifesto, underlined vertical project navigation, and distinct photographic print-collage case studies.
