# orbit

A collaborative project workspace that gives small creative teams a clear view of their priorities, progress, and shared responsibilities.

Orbit helps creative teams keep their work moving without losing the bigger picture. The workspace organizes active projects, daily priorities, and team activity around a clear, approachable dashboard. Soft lavender panels and dark purple typography create a focused atmosphere, while small color signals make progress and ownership easy to scan. The orbital symbol expresses coordinated movement around a shared goal. A working status filter and task completion controls bring the interface to life, supported by realistic project names, deadlines, and collaborator details. The design’s purpose is to make teamwork feel lighter: fewer scattered updates, more visible progress, and a shared place to find the next useful step.

## Typography

Display: Plus Jakarta Sans. Body: DM Sans.

## Logo

An orbital path and central point represent individual contributions moving around one shared purpose. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A light lavender workspace with a fixed navigation rail, spacious white project cards, precise progress details, and a calendar-led side panel.
