# orbit

A collaborative project workspace that gives small creative teams a clear view of their priorities, progress, and shared responsibilities.

Orbit brings a small creative team’s work into one considered studio dashboard. A broad week roadmap gives research, design, content, and review their own saturated stage colors, while a continuous allocation strip connects planned hours to the actual project. Compact task rows keep owners, deadlines, checklists, and progress close together. Team workload and a timed review agenda give the work a human rhythm without overwhelming the main view. A task drawer with violet controls opens the next useful decision: change a status, complete a step, or keep a working note. Quiet paper, precise typography, and clear contrast make the shared plan easy to read on a desktop or a phone.

## Typography

Display: Manrope. Body: DM Sans.

## Logo

An orbital path and central point represent individual contributions moving around one shared purpose. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A modern studio cockpit with a quiet navigation rail, dominant saturated week roadmap, one continuous project-allocation strip, compact working ledger, human workload rows, and a paper task drawer with violet controls. Manrope headings and precise DM Sans labels sit on warm gray and white.
