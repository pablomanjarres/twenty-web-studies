# Soundroom

An independent music discovery workspace for exploring releases, keeping a collection, and finding a listening mood.

Soundroom is a music discovery app for a small collection of independent ambient sketches. A wide recording-studio photograph gives the featured release a physical setting, while a compact track ledger makes the listening choices clear. Original abstract cover compositions carry each sound’s identity through the main list, mood rooms, discovery column, and persistent player. Amber selection states sit between a near-black listening canvas and a muted plum discovery desk. Listeners can play the actual short clips, seek within a track, set the volume, explore a mood, and keep a personal collection. Quiet Sora typography and carefully controlled depth make the interface feel direct, contemporary, and intimate.

## Typography

Display: Sora. Body: DM Sans.

## Logo

Nested open frames form a listening room, with a central dot marking the source of sound. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

A contemporary dark discovery app with a narrow icon rail, cinematic recording-studio release banner, amber selected track row, original square cover compositions, a plum mood/queue column, and a persistent integrated audio player. Sora interface headings and compact DM Sans labels support the listening hierarchy.
