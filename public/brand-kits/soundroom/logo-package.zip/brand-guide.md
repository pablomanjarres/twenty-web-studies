# Soundroom

An independent music discovery workspace for exploring releases, keeping a collection and building a listening queue.

Soundroom brings the intimacy of a record shop into a music discovery workspace. A compressed display face, coral panels and lilac accents sit inside a quiet black interface. Album artwork mixes concert photography with equalizer and holographic textures, giving each release a different visual presence. The page moves from a featured listening session to new records and a compact selection of tracks. Search, saved releases and a local queue give the screen a clear purpose. Its custom symbol combines a record groove with an open doorway, suggesting a room that is always ready for another sound.

## Typography

Display: Grand Mighty. Body: DM Sans.

## Logo

Nested record grooves form an open room, with a central dot marking the source of sound. Keep clear space equal to one quarter of the symbol height. The supplied wordmark is outlined; do not stretch, retype, or recolor individual parts.

## Direction

Independent record-store workspace with compressed typography, coral feature panels, lilac controls, distinct album sleeves and a restrained dark shell.
